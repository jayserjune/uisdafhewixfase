//引入express模块  
const express = require('express');
//引入multer模块  
const path = require('path');
const os = require("os");
const fs = require("fs");
const mkdirp = require('mkdirp')
//设置上传的目录，  
const app = express();
const Cache = {}
const Timer={}
const CacheList = ['account_list', 'commands']
var bodyParser = require('body-parser');
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({
//   extended: false
// }));
// 通过 storage 选项来对 上传行为 进行定制化
// 暂时不考虑数据的有效期，只是部分要缓存而已
app.use(express.json({
  limit: '100mb'
}));
app.use(bodyParser.json({
  limit: '100mb'
}));
app.use(bodyParser.urlencoded({
  limit: '100mb',
  extended: true
}));
app.use(express.static(path.join(__dirname, '/')));
app.post('/getData', function (req, res, next) {
  // console.log(req)
  // console.log(req.body)
  let _key = `${req.body.account}_${req.body.port}_${req.body.zone}_${req.body.key}`
  console.log('getData,', _key)
  if (CacheList.includes(req.body.key) && Cache[_key]) {
    return res.status(200).json({
      success: true,
      message: '读取成功',
      code: 200,
      data: Cache[_key]
    });
  } else {
    const filePath = path.join(os.homedir(), `/mtpCache_${req.body.port}_${req.body.account}/storage/${req.body.zone}/${req.body.key}.json`);
    let data = {
      value: ''
    }
    if (fs.existsSync(filePath)) {
      data = fs.readFileSync(filePath, 'utf-8');
      data = JSON.parse(data)
      if (CacheList.includes(req.body.key)) {
        Cache[_key] = data.value
      }
    }
    return res.status(200).json({
      success: true,
      message: '读取成功',
      code: 200,
      data: data.value
    });
  }
});
app.post('/saveData', function (req, res, next) {
  let _key = `${req.body.account}_${req.body.port}_${req.body.zone}_${req.body.key}`
  console.log('saveData,', _key)
  const filePath = path.join(os.homedir(), `/mtpCache_${req.body.port}_${req.body.account}/storage/${req.body.zone}/${req.body.key}.json`);
  const _data = {
    zone: req.body.zone,
    key: req.body.key,
    expireTime: req.body.expireTime ? req.body.expireTime : null, // 过期时间
    createTime: new Date().getTime(), //记录何时将值存入缓存，毫秒级
    value: req.body.value
  }
  const dirPath = path.join(os.homedir(), `/mtpCache_${req.body.port}_${req.body.account}/storage/${req.body.zone}/`);
  // 有缓存的
  if (CacheList.includes(req.body.key)) {
    Cache[_key] = req.body.value
    // 延迟保存
    clearTimeout(Timer[_key])
    Timer[_key] = setTimeout(() => {
      // 创建目录
      mkdirp(dirPath).then(res => {
        fs.writeFile(filePath, JSON.stringify(_data), function (err) {
          console.log(err)
        });
        let _random_time=''+new Date().getHours()+'_'+Math.floor(new Date().getMinutes()/5)
        const filePath2 = path.join(os.homedir(), `/mtpCache_${req.body.port}_${req.body.account}/storage/${req.body.zone}/${req.body.key}.${_random_time}.json`);
        console.log(filePath2)
        fs.writeFile(filePath2, JSON.stringify(_data), function (err) {
          console.log(err)
        });
      }).catch(err => {
        console.log('缓存目录初始化失败:' + JSON.stringify(err))
      })
    }, 300)
    // 保存到文件里去

    return res.status(200).json({
      success: true,
      message: '保存成功',
      code: 200,
      data: req.body.value
    });
  } else {
    // 创建目录
    mkdirp(dirPath).then(Mres => {
      fs.writeFile(filePath, JSON.stringify(_data), function (err) {
        console.log(err)
        // 保存到文件里去

        return res.status(200).json({
          success: true,
          message: '保存成功',
          code: 200,
          data: req.body.value
        });
      });
    }).catch(err => {
      console.log('缓存目录初始化失败:' + JSON.stringify(err))
    })
  }

});

app.listen(10086)